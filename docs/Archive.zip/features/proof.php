<?php
    /*
    *SHILLERS NETWORK PROOF OF WORK* 

Below are evidences of our work, please you can confirm;

PROJECT : EXPANZ PROTOCOL 
SHILLING PROOF : https://t.me/EXPANZINFLUENCERS
REFERENCE: @Chris_Defi @bitcoinconsultant 

PROJECT : MBMX UNIVERSE 
SHILLING PROOF : https://t.me/MBMXINFLUENCER
REFERENCE: @kentkristensen 

PROJECT : ARTEMIS VISION 
SHILLING PROOF :https://t.me/ArtemisVisionShill
REFERENCE: @Artemis_Vision_io 

PROJECT : SPACE FALCON
SHILLING PROOF : https://t.me/SpaceFalconShill
REFERENCE: @EthanLau93 

PROJECT : Zomfi 
SHILLING PROOF : https://t.me/zomfi_shilling
REFERENCE: @Johnny_Zomfi1

PROJECT : WEB3COP
SHILLING PROOF: https://t.me/+4INyZLehUCtlODE0
REFERENCE: @Command21 @Cryplord

PROJECT: GODWARS
SHILLING PROOF:
https://t.me/+0X1pYQ41fioyZDhk
REFERENCE:
Community Website: https://godwars.io https://t.me/GodWars_Dev
    */

?>

<?php
    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>EXPANZ PROTOCOL</h3>
                <a href='https://t.me/EXPANZINFLUENCERS'>link</a>
                <div>@Chris_Defi | @bitcoinconsultant</div>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>MBMX UNIVERSE</h3>
                <a href='https://t.me/MBMXINFLUENCER'>link</a>
                <div>@kentkristensen</div>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>ARTEMIS VISION</h3>
                <a href='https://t.me/ArtemisVisionShill'>link</a>
                <div>@Artemis_Vision_io</div>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>SPACE FALCON</h3>
                <a href='https://t.me/SpaceFalconShill'>link</a>
                <div>@EthanLau93</div>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>Zomfi</h3>
                <a href='https://t.me/zomfi_shilling'>link</a>
                <div>@Johnny_Zomfi1</div>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>WEB3COP</h3>
                <a href='https://t.me/+4INyZLehUCtlODE0'>link</a>
                <div>@Command21 | @Cryplord</div>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-4 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                
                <h3 style='color: rgba(0, 0, 0, 0.54);'>GODWARS</h3>
                <a href='https://t.me/+0X1pYQ41fioyZDhk'>link</a>
                <div> <a href='https://godwars.io https://t.me/GodWars_Dev'>Reference</a> </div>
            </div>
        </div>
    ";

?>