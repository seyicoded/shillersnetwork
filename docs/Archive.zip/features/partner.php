<?php
    echo "
        <div class='col-md-11 miid m-5 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                <div style='justify-content: center; align-items: center;'>
                    <img class='partner-image' alt='image' src='../assets/new-img/pinksale.jpg' style='' />
                </div>
                <h3 style='color: rgba(0, 0, 0, 0.54);'>PINKSALE</h3>
                <a href='http://docs.pinksale.finance/important/marketing-services'>link</a>
            </div>
        </div>
    ";

    echo "
        <div class='col-md-6 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                <div style='justify-content: center; align-items: center;'>
                    <img class='partner-image' alt='image' src='../assets/new-img/bitmart.png' style='' />
                </div>
                <h3 style='color: rgba(0, 0, 0, 0.54);'>BITMART</h3>
                <!-- <a href='http://docs.pinksale.finance/important/marketing-services'>link</a> -->
            </div>
        </div>
    ";

    echo "
        <div class='col-md-6 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                <div style='justify-content: center; align-items: center;'>
                    <img class='partner-image' alt='image' src='../assets/new-img/coingecko.png' style='' />
                </div>
                <h3 style='color: rgba(0, 0, 0, 0.54);'>COIN GECKO</h3>
                <!-- <a href='http://docs.pinksale.finance/important/marketing-services'>link</a> -->
            </div>
        </div>
    ";

    echo "
        <div class='col-md-6 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                <div style='justify-content: center; align-items: center;'>
                    <img class='partner-image' alt='image' src='../assets/new-img/cmc.png' style='' />
                </div>
                <h3 style='color: rgba(0, 0, 0, 0.54);'>COIN MARKET CAP</h3>
                <!-- <a href='http://docs.pinksale.finance/important/marketing-services'>link</a> -->
            </div>
        </div>
    ";

    echo "
        <div class='col-md-6 text-center align-items-center justify-content-center'>
            <div class='card shadow align-self-center p-3' style='margin: 20px'>
                <div style='justify-content: center; align-items: center;'>
                    <img class='partner-image' alt='image' src='../assets/new-img/kucoin.png' style='' />
                </div>
                <h3 style='color: rgba(0, 0, 0, 0.54);'>KUCOIN</h3>
                <!-- <a href='http://docs.pinksale.finance/important/marketing-services'>link</a> -->
            </div>
        </div>
    ";
?>